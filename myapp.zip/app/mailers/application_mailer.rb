class ApplicationMailer < ActionMailer::Base
  default from: "no-reply@cptcambio.com"
  layout 'mailer'
end
