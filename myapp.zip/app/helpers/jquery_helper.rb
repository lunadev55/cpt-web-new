module JqueryHelper
end
