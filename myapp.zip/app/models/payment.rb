class Payment < ActiveRecord::Base
    belongs_to :user
end
