class Wallet < ActiveRecord::Base
    belongs_to :user
end
